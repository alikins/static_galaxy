some tools for inspecting how collection loading works
